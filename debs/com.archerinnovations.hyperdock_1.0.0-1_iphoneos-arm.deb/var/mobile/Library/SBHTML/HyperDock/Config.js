var Color = "#1D1D1D"; // hex color goes here (remember to add “#” before your code. (Example: #1D1D1D)
var Opacity = "0.85"; // change the opacity (value between 0 and 1)
var Top = "88.65%"; // position from the top (remember to add units) - I recommend using percentages.
var Left = "12.5%"; // position from the left (remember to add units) - I recommend using percentages.
var Width = "75%"; // Self-Explanatory - I recommend using percentages.
var Height = "10%"; // Self-Explanatory - I recommend using percentages.
var BorderRadius = "12px"; // Changes how rounded or sharp the corners are. - I recommend using “px” as the unit.
var Defaults = ""; // top:88.65%; left:12.5%; width:75%; height:10%;border-radius:12px; opacity:0.85;
